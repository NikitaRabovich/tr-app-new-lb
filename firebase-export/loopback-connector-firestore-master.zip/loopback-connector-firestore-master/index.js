module.exports = require('./lib/firestore.js');
